print 'Hello, Kiddypi'

raw_input("\n\nPress the enter key to exit:")
